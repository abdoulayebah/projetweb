<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Accueil</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->users;

include 'fonctions.php';

if(!champsPleins()){
	include 'FormulaireInscription.php';
	echo'<script>alert("Formulaire n\'est pas bien rempli")</script>';
}
	else{
		$motDePassePerso=genererPassword(10);
		$date="".$_POST["jour"]."/".$_POST["mois"]."/".$_POST["annee"];
		if(!addUser(htmlentities($_POST["nom"]),htmlentities($_POST["prenom"]), htmlentities($_POST["login"]), $motDePassePerso, $date)){
		include'FormulaireInscription.php';
		echo'<script>alert("Utilisateur deja inscrit! veuillez changez de login")</script>';
		}else{
			$objet="Inscription  Technology.fr";
			$message ="Bonjour ".$_POST["prenom"].", nous vous remercions pour votre inscription sur notre site \"Technology.fr\", votre lobin est: ".$_POST["login"]." et votre mot de passe est: ".$motDePassePerso; 
			mail($_POST["login"],$objet, $message);
			$_SESSION["login"]=$_POST["login"];
			$_SESSION["prenom"]=$_POST["prenom"];
			$_SESSION["nom"]=$_POST["nom"];
			echo '<p style="text-align:center">';
			echo "Bonjour $_SESSION[prenom]!<br />";
			echo 'Vous venez de s\'inscrire.<br />';
			echo "Votre login est: $_SESSION[login]<br />";
			echo "Votre mot de pass <strong>$motDePassePerso</strong> est envoyée sur votre mail<br />";
			echo '<a href="index.php">Vers la page d\'accueil</a>';
			echo '</p>';
			
			}
	}
?>
</body>
</html>
