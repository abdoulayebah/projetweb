<?php
include '../TP8/connectBase.php';
		$db=$m->abdbah39;
		$collection=$db->articles;
	
	
	$newdata=array('$set'=>array("permition"=>"yes"));
	$collection->update(array("_id"=>new MongoId($_REQUEST["_id"])),$newdata);
	header('location:administration.php');
	

?>
