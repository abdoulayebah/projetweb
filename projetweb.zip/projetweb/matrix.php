<div id='matrix'></div>
<script>
/*letters = ['ン','ワ','ラ','ヤ','マ','ハ','ナ','タ','サ','カ','ア','リ','ミ','ヒ','ニ','チ','シ','キ','イ','ル','ユ','ム','フ','ヌ','ツ','ス','ク','ウ','レ','メ','ヘ','ネ','テ','セ','ケ','エ','ヲ','ヨ','モ','ホ','ノ','ト','ソ','コ','オ']*/
(function () {
	var meshsize = 13,
		matrix = document.getElementById('matrix'),
		info = document.getElementById('info'),
		colnum = Math.ceil(matrix.offsetWidth/12),
		rownum = Math.ceil(matrix.offsetHeight/12),
	
	// create mesh
	
		row = null,
		cells = [],
		cell = null,
		total = colnum*rownum,
		i = 0,
		frag = document.createDocumentFragment(),
		letters = ['0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0','1','0'],
		all = letters.length-1;

	for (;i<total;i++) {
		cell = document.createElement('div');
		cell.style.width = meshsize+'px';
		cell.style.height = meshsize+'px';
		cell.innerHTML = letters[Math.floor(Math.random()*all)];
		cell.style.left = (i%colnum)*meshsize+'px';
		cell.style.top = Math.floor(Math.abs(i/colnum))*meshsize+'px';
		cell.type = 0;
		cell.className = 'cell';
		frag.appendChild(cell);
		cells.push(cell);
	}
	matrix.appendChild(frag);

	// create anim
	var now = 0,
		id = null,
		time = 50,
		active = {},
		uniq = 0,
		render = function () {
		
			// add new active
			i = Math.floor(Math.random()*(colnum/7));
			while(i--){
				id = Math.floor(Math.random()*colnum);
				cell = cells[id];
				z = Math.ceil(rownum/4);
				while(z--){
					tmp = id+z*colnum;
					if (cells[tmp > total-1 ? tmp-total : tmp].type ) {cell = false;break;}
				}
				if(!cell)continue;
				temp = Math.floor(Math.random()*all);
				cell.innerHTML = letters[temp];
				cell.type = 1;
				cell.style.opacity = 1;
				cell.style.color = "#5ec58f";
				cell.style.display = 'block';
				active[uniq++] = {row:0, cell:cell, col:id, temp:temp};
			}

			// move
			for (i in active) {
				if (active[i].row == rownum) {
					cell.innerHTML = letters[active[i].temp];
					active[i].cell.type = 0;
					active[i].cell.style.color = "#366900";
					delete active[i];
					continue;
				}
				// old cell
				cell.innerHTML = letters[active[i].temp];
				active[i].cell.type = 0;
				active[i].cell.style.color = "#366900";
				// new cell
				temp = Math.floor(Math.random()*25);
				cell = cells[colnum*active[i].row+active[i].col];
				cell.innerHTML = letters[temp];
				cell.style.opacity = 1;
				cell.style.color = "#5ec58f";
				cell.style.display = 'block';
				cell.type = 1;
				active[i].row++;
				active[i].cell = cell;
				active[i].temp = temp;
			}

			// symbols opacity changing
			var i = total;
			while (i--) {
				if (cells[i].type == 0 && cells[i].style.display != 'none') {
					temp = cells[i].style.opacity*1 - 0.05;
					if (temp <= 0.05) {// wtf?
						cells[i].style.display = 'none';
						cells[i].style.opacity = 1;
					} else {
						cells[i].style.opacity = temp;
					}
				}
			}

			// random change of symbols
			i = 10;
			while (i--) {
				cell = cells[Math.floor(Math.random()*total)];
				cell.innerHTML = letters[Math.floor(Math.random()*all)];
			}

			setTimeout(render,50);
		}

	render();

})();
</script>
