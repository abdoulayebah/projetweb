<?php
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->users;
include'fonctions.php';
if(sessionIsStarted()){
	header('location:FormulaireRechercheAvancee.php');
	exit;
}else{
	include('FormulaireConnexion.php');
	echo'<script>alert("cette fonction necessite une connexion ")</script>';
}	
?>
