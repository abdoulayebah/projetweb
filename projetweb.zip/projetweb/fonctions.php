<?php
function champsPleins()
{
	return (isset($_POST["prenom"], $_POST["nom"],$_POST["login"]) && $_POST["prenom"] != "" && $_POST["nom"] != "" && $_POST["login"] != "");
}



function genererPassword($qtd){
//dans $caracteres on a mis tous les caractères qu'on souhaite utiliser pour generer notre mot de passe.
$Caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
$nbreDeCaracteres = strlen($Caracteres); // contient le nombre de caractères que contient la chaine $caracteres.
$Caracteres--; // car on utilise le codage utf-8 (ce dernier donne le nombre de caractères majoré de 1);

$motDePasse=NULL;
    for($x=1;$x<=$qtd;$x++){ //$qtd contient le nombre de caractères que contiendra le mot de passe.
        $Position = rand(0,$nbreDeCaracteres);
        $motDePasse .= substr($Caracteres,$Position,1);
    }

return $motDePasse;
}

function addUser($nom, $prenom, $login, $passwrd, $date)
{	
	global $collection;
	$query=array("login"=>$login);
	$cursor=$collection->find($query);
	if($cursor->count() != 0){
		return false;
	}else{
		$user=array("nom"=>$nom, "prenom"=>$prenom,"login"=>$login, "password"=>sha1($passwrd), "dateNaissance"=>$date, "admin"=>"no");
		$collection->insert($user);
		return true;
	}
}

function userExist($login, $mdp)
{
	global $collection;
	$query=array("login"=>$login, "password"=>sha1($mdp));
	$cursor=$collection->find($query);
	return ($cursor->count() != 0);
		
}
function startingSession($login, $mdp)
{
		global $collection;
		$query=array("login"=>$login, "password"=>sha1($mdp));
		$cursor=$collection->find($query);
		foreach($cursor as $c=>$v){
		
		$_SESSION["prenom"]=$v["prenom"];
		$_SESSION["nom"]=$v["nom"];
		$_SESSION["login"]=$v["login"];
		
		}
		
	
}
function sessionIsStarted()
{
	return (isset($_SESSION["login"]) && $_SESSION["login"] != "");
}


function RechercheTitreAuteur ($rubrique, $titre, $auteur) {
global $collection;
	if ($_POST["titre"]!="" && $_POST["auteur"]!="" && ($_POST["rubrique"]!="")){
		$query=array("rubrique"=>$rubrique, "titre"=>$titre, "auteur"=>$auteur);
		$cursor=$collection->find($query);
		return $cursor;			
	}
	else if ($_POST["rubrique"]!="" && $_POST["titre"]!="") {
		$query=array("rubrique"=>$rubrique,"titre"=>$titre);
		$cursor=$collection->find($query);
		return $cursor;
	}
	else if ($_POST["rubrique"]!="" && $_POST["auteur"]!="") {
		$query=array("rubrique"=>$rubrique,"auteur"=>$auteur);
		$cursor=$collection->find($query);
		return $cursor;
	}
	else if ($_POST["titre"]!="" && $_POST["auteur"]!="") {
		$query=array("titre"=>$titre,"auteur"=>$auteur);
		$cursor=$collection->find($query);
		return $cursor;
	}
	else if ($_POST["rubrique"]!="") {
		$query=array("rubrique"=>$rubrique);
		$cursor=$collection->find($query);
		return $cursor;
	}

	else if ($_POST["auteur"]!="") {
		$query=array("auteur"=>$auteur);
		$cursor=$collection->find($query);
		return $cursor;
	}
	else  {
		$query=array("titre"=>$titre);
		$cursor=$collection->find($query);
		return $cursor;
	}	
}


/* on a utiliser cette methode parceque la version mongodb installée au script est la version 1.4.4 qui n'accepte pas l'operateur $or. 
function rechercheSimple ($clef) {
	global $collection;
	$query = array("permition"=>"yes", '$or' => array('cle1' => $clef, 'cle2' => $clef,'cle3' => $clef,'cle4' => $clef));
	$cursor=$collection->find($query);
	return $cursor;
}
 */

function rechercheSimple ($clef) {
	global $collection;
	$query1=array('permition'=>'yes','cle1'=>$clef);
    $query2=array('permition'=>'yes','cle2'=>$clef);
	$query3=array('permition'=>'yes','cle3'=>$clef);
	$query4=array('permition'=>'yes','cle4'=>$clef);
		$cursor=$collection->find($query1);
		if($cursor->count() > 0){
			return $cursor;
		}else{
			$cursor=$collection->find($query2);
			if($cursor->count() > 0){
				return $cursor;
			}else{
				$cursor=$collection->find($query3);
				if($cursor->count() > 0){
					return $cursor;
				}else{
					$cursor=$collection->find($query4);
					return $cursor;
					
				}	
			}

		}		
}

function cree_article(){
	$article=array();
	$article["userID"]=$_SESSION["login"];
	$article['rubrique']=check_request('rubrique');
	$article['auteur']=$_SESSION["nom"]." ".$_SESSION["prenom"];
	$article['titre']=check_request('titre');
	$article['image']=check_request('image');
	$article['contenu']=check_request('contenu');
	$article['cle1']=check_request('cle1');
	$article['cle2']=check_request('cle2');
	$article['cle3']=check_request('cle3');
	$article['cle4']=check_request('cle4');
	$article['date']=date('l jS F Y h:i:s A');
	$article['comments']=array();
	$article['permition']="no";
	if(check_article($article)){
		return $article;
		}else{
			return null;
			}
}
function check_article($article){
	return ($article['titre'] != "" || $article['contenu'] != ""); 
}
function check_request($champ){
	if(isset($_REQUEST[$champ]))
	return htmlentities($_REQUEST[$champ]);
	return "";
}	
function ajout_article($article){
	global $collection;
	$collection->insert($article);
}

function getUnpublished(){
	global $collection;
	$query=array("permition"=>"no");
		$cursor=$collection->find($query);
		if($cursor->count() != 0){
		return $cursor;
		}else{
			return null;
			}
}

function getPublished(){
global $collection;
	$query=array("permition"=>"yes");
		$cursor=$collection->find($query);
		return $cursor;
}
	
function getArticlesParClefVal($clef,$val)
{
	global $db;
	$query=array("$clef"=>"$val");
		$cursor=$db->articles->find($query);
		if($cursor->count() != 0){
		return $cursor;
		}else{
			return null;
			}
	
}
	
function afficherListeArticles($liste){
	foreach($liste as $c=>$v){
		echo '<div class="article">';
		echo "Rubrique:".$v["rubrique"]."<br />";
		echo 'Titre:<a href="afficherUnArticle.php?id='.$v["_id"].'">'.$v["titre"].'</a><br />';
		echo "Auteur:".$v["auteur"]."<br />";
		echo "Date de publication: ".$v["date"]."<br />";
		echo '<p class="contenuArticle">';
		echo substr($v["contenu"],0,200)."...<br />";
		echo '<a href="afficherUnArticle.php?id='.$v["_id"].'">Lire la suite</a><br />';
		echo '</p>';
		echo '</div>';
		
	}
}

function afficherListeArticlesPourGestion($liste){
	foreach($liste as $c=>$v){
		echo '<div class="article">';
		echo "<span>Rubrique:".$v["rubrique"]."</span><br />";
		echo 'Titre:<a href="afficherUnArticleGestionCompte.php?id='.$v["_id"].'">'.$v["titre"].'</a><br />';
		echo "<span>Auteur:".$v["auteur"]."</span><br />";
		echo "Date de publication: ".$v["date"]."<br />";
		echo '<p class="contenuArticle">';
		echo substr($v["contenu"],0,200)."...";
		echo '<a href="afficherUnArticleGestionCompte.php?id='.$v["_id"].'">Lire la suite</a><br />';
		echo '</p>';
		echo '</div>';
		
	}
}



function supprimerArticle($id)
{
	global $collection;
		$query=array("_id"=>new MongoId($id));
		$collection->remove($query);
}

function afficherUnArticleParId ($id) {
		global $collection;
		$query=array("_id"=>new MongoId($id));
		$cursor=$collection->find($query);
		echo '<div class="article">';
		foreach($cursor as $c=>$v){
				echo "<span>Rubrique:".$v["rubrique"]."</span><br />";
				 echo "<span>Titre:".$v["titre"]."</span><br />\n";
				 echo "<span>Auteur:".$v["auteur"]."</span><br />\n";
				 echo "<span>Date de publication: ".$v["date"]."</span><br />\n";
				 
				 echo '<p class="contenuArticle">'."\n";
				 if($v["image"] != ""){
				 echo '<img src="'.$v["image"].'" align="left" vspace="10" hspace="10" width="20%">';
				 }
				 echo $v["contenu"];
				 echo "</p>\n";
		echo '</div>';
				 echo '<div class="comments">'."\n";
				 foreach ($v["comments"] as $clef=>$val){
					echo '<div class="comment">'."\n";
					echo '<span>'.$val["auteur"].':</span><br />'."\n";
					echo '<div class="texteComment">'."\n";
					echo $val["text"]."\n";
					echo '</div>'."\n";
					echo '</div>'."\n";
				 }
				echo '</div>'."\n";
				 
		}
		
}

function admin(){
global $db;
if(!isset($_SESSION["login"]) || $_SESSION["login"]=="" ){
return false;
}else{
$query=array("login"=>$_SESSION["login"]);
$cursor=$db->users->find($query);
	foreach ($cursor as $c=>$v){
		if ($v["admin"]==="yes") return true;
		return false;
	}
}
}

function publie($id){
global $collection;
	$cursor=$collection->find(array("_id"=>new MongoId($id)));
	foreach($cursor as $c=>$v){
		return ($v["permition"] == "yes");
	}
}



?>



