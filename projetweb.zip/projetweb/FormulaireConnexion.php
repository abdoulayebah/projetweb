<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Connexion</title>
	<link rel="stylesheet" href="styles.css">
	
	<script>
	function identif(){
		alert("Verifiez votre mail!");
	}
	</script>
</head>
<body>

<?php
include 'mainmenu1.php';
?>

<div id="main_center_block">

			<div class="formulaireConnexion">
				<div class="contenuFormulaireConnexion">
					<h4>Connexion</h4>					
					<form action="do_connexion.php" method="POST">
						<input type="email" id="id" name="login" placeholder="Identifiant" autocomplete="on">
						<input type="password" id="passwrd" name="mdp" value="" placeholder="Mot de passe"><br />
						
						<div class="Connexion">
							<input type="submit" id="boutonConnexion" value="connexion"><br />
						</div>
					</form>
						<div class="AideIdentification">
							<input type="button" onclick="identif()" id="lien" value="Mot de passe oublié"><br/>
						</div>
				</div>			
			</div>
		
</div>
</body>
</html>
