<?php
	
	include '../TP8/connectBase.php';
	$db=$m->abdbah39;
	$collection=$db->articles;
	session_start();
	include 'fonctions.php';
	
	$resultat= RechercheTitreAuteur ($_POST["rubrique"], $_POST["titre"], $_POST["auteur"]);
			if($resultat->count()>0) {
				afficherListeArticles($resultat);
			}
			else {
				echo '<script>alert("il n \' y a aucun article correspondant à vos critères de recherche")</script>';
				
			}
		?>
	

	

