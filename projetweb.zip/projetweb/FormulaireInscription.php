<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Inscription</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>


<?php
include 'mainmenu1.php';
?>

<div id="main_center_block">
			<div class="FormulaireInscription">
				<h4>S'inscrire</h4>
				<form action="do_inscription.php" method="POST">
					<div class="nom">	
						<input type="text" id="nom" name="nom" placeholder="Nom" maxlength="30" autocomplete="off"><p class="etoile">*</p>
					</div>
					<div class="prenom">
						<input type="text" id="prenom" name="prenom" placeholder="Prénom" maxlength="30" autocomplete="off"><p class="etoile">*</p><br />
					</div>
					<div class="identifiant">
						<input type="email" id="idl" name="login" placeholder="Identifiant\mail"  autocomplete="off"> <!-- je ferais de telle sorte l'identifiatnt et l'option soient sur la même ligne-->
					</div>
										
					<div class="telephoneNumber">
						<input type="text" id="phoneNumber" name="telNumber" maxlenght="15" placeholder="Numéro mobile" autocomplete="off">
					</div>
				
					<p id="dateNaissance" >Date de naissance </p> <!--doit etre sur la meme ligne que jour, mois et année-->
					
					<div class="dateNaissance">
						<select name="jour" id="jour">
							<option selected disabled>Jour</option>
							<?php
							for($i=1; $i<32; $i++){
								echo  "<option value=\"".$i."\">".$i."</option>";
							}
							?>
							
						</select>
						<select name="mois" id="mois">
							<option selected disabled>Mois</option>
							<option value="1">janvier</option>
							<option value="2">Fevrier</option>
							<option value="3">Mars</option>
							<option value="4">Avril</option>
							<option value="5">Mais</option>
							<option value="6">Juin</option>
							<option value="7">Juillet</option>
							<option value="8">Août</option>
							<option value="9">Septembre</option>
							<option value="10">Octombre</option>
							<option value="11">Novembre</option>
							<option value="12">Decembre</option>
						</select>
						<select name="annee" id="annee">
							<option selected disabled>Année</option>
							<?php
							$year=date("Y");
							
							for($i=0; $i<80; $i++){
								echo  "<option value=\"".$year."\">".$year."</option>";
								$year-=1;
							}
							
							?>
							
								
							
						</select><br />
					</div>					
					<div class="sexe">
						<div class="sexe">
							<input type="radio" id="homme" name="sexe" value="h">
							<label for="homme">Homme</label>
							<input type="radio" id="femme" name="sexe" value="f">
							<label for="femme">Femme</label>
						</div>
					</div>
					<p>J'accepte les <a href="conditionUtilisations.html">conditions d'utilisations </a> et je certifie que les informations fournies sont correctes.</p>	
					<input type="submit" value="Crée mon Compte" id="boutonCreeCompte">
		
				</form>
			</div>
	</div>
	</body>
</html>
