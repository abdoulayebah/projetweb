<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->articles;
include'fonctions.php';
$article=cree_article();
if($article!=null){
	ajout_article($article);
	header('location:index.php');
}else{
	include 'FormulaireDepotDArticle.php';
	echo '<script>alert("Les shamps avec * sont obligatoire")</script>';
	}
?>
