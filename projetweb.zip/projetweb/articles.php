<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Accueil</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->articles;
include'fonctions.php';
if(sessionIsStarted()){
include 'mainmenu2.php';
}else{
include 'mainmenu1.php';
}
?>

<div id="main_center_block">
	
<?php
afficherListeArticles(getPublished());
?>
	
</div>
</body>
</html>
