<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="UTF-8">
		<title>Recherche Avancée</title>
		<link rel="stylesheet" href="styles.css">
	</head>
	<body>

	<?php
		session_start();
		include '../TP8/connectBase.php';
		$db=$m->abdbah39;
		$collection=$db->articles;
		include'fonctions.php';
		if(!sessionIsStarted()){
		header ('location:index.php');
		}
		include 'mainmenu2.php';
	?>
		<div id="main_center_block">
			<div class="FormulaireRechercheAvancee">
				<form action="FormulaireRechercheAvancee.php" method="POST" >
					<div class="contenuFormulaire">
						
							<select name="rubrique" class="rub">
								<option selected disabled value="">Rubrique</option>
								<option value="Telephones">Téléphones</option>
								<option value="Ordinateur" >Ordinateurs</option>
								<option value="Application" >Applications</option>
								<option value="Accessoires ordinateurs" >Accessoires ordinateurs</option>
								<option value="Accessoires telephoniques" >Accessoires téléphoniques</option>
							</select>
						
						<input type="text" name="titre" id="titreArticle" placeholder="titre de l'article"  autocomplete="on">
						
						<input type="text" name="auteur" id="auteur" placeholder="Auteur de l'Article" maxlength="30" autocomplete="on">
						
						<div class="Soumettre">
							<input type="submit" value="Chercher" id="boutonSoumettre">
						</div>
					</div>
				</form>
			</div>
		
		
		<?php
		if(isset($_POST["rubrique"], $_POST["titre"], $_POST["auteur"])){
			$resultat= RechercheTitreAuteur ($_POST["rubrique"], $_POST["titre"], $_POST["auteur"]);
			if($resultat->count()>0) {
				afficherListeArticles($resultat);
			}
			else {
				echo '<script>alert("il n \' y a aucun article correspondant à vos critères de recherche")</script>';
				
			}
		}else{
			if(isset($_POST["motClef"])){
			$resultat=rechercheSimple($_POST["motClef"]);
			if($resultat->count()>0) {
				afficherListeArticles($resultat);
			}
			else {
				echo '<script>alert("il n \' y a aucun article correspondant à vos critères de recherche")</script>';
				
			}
			
			}
			
		}

?>	
</div>	
	</body>
</html>
