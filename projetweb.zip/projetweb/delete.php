<?php
session_start();
include '../connectBase.php';
$db=$m->sgasan32;
$collection=$db->users;
$collection->remove();
?>