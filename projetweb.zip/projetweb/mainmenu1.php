<div id="topbar">
<?php
include 'matrix.php';
?>
<nav id="main-menu">
	<ul>
		<li>
			<a href="index.php">
			<span class="text-top">TECHNOLOGY</span>
			<span class="text-bottom">Accueil</span>
			</a>
		</li>
		<li>
			
			<span class="text-top"><a href="articles.php">Articles</a></span>
			<span class="text-bottom"><a href="AutorisationDepot.php">Depot d'article</a></span>
			
		</li>
		<li id="recherche">
			<span class="text-top">
			<form action="FormulaireRechercheAvancee.php" method="POST">
			<input type="text" name="motClef" placeholder="recherche" style="width:100%">
			</form>
			</span>
			<span class="text-bottom"><a href="AutorisationRecherche.php">Recherche avancée</a></span>
			
		</li>
		<li>
			<span class="text-top">On se connait?</span>
			<span class="text-bottom"><a href="FormulaireConnexion.php" style="display:inline">Connexion</a> ou <a href="FormulaireInscription.php" style="display:inline">inscription.</a></span>
			
		</li>
	</ul>
</nav>
</div>
