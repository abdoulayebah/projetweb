<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Accueil</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->articles;
include'fonctions.php';
if(sessionIsStarted()){
include 'mainmenu2.php';
}else{
header ('location:index.php');
}
?>

<div id="main_center_block">

<?php

if (admin()){
$liste= getUnpublished();

if($liste != null){
afficherListeArticles($liste);
}else{
	echo'Il n\'y apas d\'articles à publier';
}
}else{
echo '<p style="text-align:center; color:red">';
echo "WARNING!<br />";
echo 'VOUS N\'ETES PAS UN ADMINISTRATEUR DU SITE';

}

?>

</div>
</body>
</html>
