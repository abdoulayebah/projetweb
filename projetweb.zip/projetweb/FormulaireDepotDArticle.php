<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="UTF-8">
		<title>Depot d'article</title>
		<link rel="stylesheet" href="styles.css">
	</head>
	<body>

	<?php
		session_start();
		include '../TP8/connectBase.php';
		$db=$m->abdbah39;
		$collection=$db->articles;
		include'fonctions.php';
		if(!sessionIsStarted()){
		header ('location:index.php');
		exit;
		}
		include 'mainmenu2.php';
		
	?>
		<div id="main_center_block">
				
			<div class="FormulaireDepotDArticle">
				<form action="do_depose.php" method="POST" >
					<div class="contenuFormulaire">
						
							<select name="rubrique" class="rub">
								<option selected disabled value="">Rubrique</option>
								<option value="Telephones">Téléphones</option>
								<option value="Ordinateur" >Ordinateurs</option>
								<option value="Application" >Applications</option>
								<option value="Accessoires ordinateurs" >Accessoires ordinateurs</option>
								<option value="Accessoires telephoniques" >Accessoires téléphoniques</option>
							</select>
						
						
							<input type="text" name="titre" id="titreArticle" placeholder="titre de l'article" maxlength="30" autocomplete="on">
						
						
							<input type="text" name="image" id="image" placeholder="url de l'image" autocomplete="on">
						
						
							<textarea name="contenu" rows="15" cols="90" id="contenu" placeholder="contenu de l'article"></textarea>
						
							<div class="motClef">
								<input type="text" name="cle1" id="mot1" placeholder="mot clef 1" autocomplete="on">
								<input type="text" name="cle2" id="mot2" placeholder="mot clef 2" autocomplete="on">
								<input type="text" name="cle3" id="mot3" placeholder="mot clef 3" autocomplete="on">
								<input type="text" name="cle4" id="mot4" placeholder="mot clef 4" autocomplete="on">
							</div>
						<div class="Soumettre">
							<input type="submit" value="Soumettre" id="boutonSoumettre">
						</div>
					</div>
				</form>
			</div>
			
		</div>
				
			
	</body>
</html>
