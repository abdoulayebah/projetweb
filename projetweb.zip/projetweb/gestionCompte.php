<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Mon Compte</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->articles;
include'fonctions.php';
if(!sessionIsStarted()){
		header ('location:index.php');
		}
include 'mainmenu2.php';


echo '<div id="main_center_block">';

$liste=getArticlesParClefVal("userID","$_SESSION[login]");
if($liste != null){
afficherListeArticlesPourGestion($liste);
}else{
	echo '<h6>Vous n\'avez pas encore deposé les articles sur le site</h6>';
}
?>
</div>
</body>
</html>
