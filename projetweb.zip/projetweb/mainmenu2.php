<div id="topbar">
<?php
include 'matrix.php';
?>
<nav id="main-menu">
	<ul>
		<li>
			<a href="index.php">
			<span class="text-top">TECHNOLOGY</span>
			<span class="text-bottom">Accueil</span>
			</a>
		</li>
		<li>
			<span class="text-top"><a href="articles.php">Articles</a></span>
			<span class="text-bottom"><a href="FormulaireDepotDArticle.php">Depot d'article</a></span>
		</li>
		<li id="recherche">
			<span class="text-top">
			<form action="FormulaireRechercheAvancee.php" method="POST">
			<input type="text" name="motClef" placeholder="recherche" style="width:100%">
			</form>
			</span>
			<span class="text-bottom"><a href="FormulaireRechercheAvancee.php">Recherche avancée</a></span>
			
		</li>
		<li>
			<span class="text-top" style="text-align:right">Bienvenue <?php echo"$_SESSION[prenom]";?>!</span>
			<?php
			if(admin()){
				echo '<span class="text-bottom"><a href="administration.php" style="display:inline">Administration</a> ou <a href="deconnexion.php" style="display:inline">deconnexion</a></span>';
				}else{
				echo '<span class="text-bottom"><a href="gestionCompte.php" style="display:inline">Mon compte</a> ou <a href="deconnexion.php" style="display:inline">deconnexion</a></span>';
			}
			
			?>
		</li>
	</ul>
</nav>
</div>
