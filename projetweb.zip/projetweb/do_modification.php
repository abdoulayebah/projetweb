<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->articles;
include'fonctions.php';
if(!sessionIsStarted()){
		header ('location:index.php');
		exit;
		}
	$newdata=array('$set'=>array("titre"=>$_REQUEST["titre"],"image"=>$_REQUEST["image"], "contenu"=>$_REQUEST["contenu"], "permition"=>"no"));
	$collection->update(array("_id"=>new MongoId($_REQUEST["id"])),$newdata);
	header('location:gestionCompte.php');

?>
