<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Affichage</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->articles;
include'fonctions.php';
if(sessionIsStarted()){
include 'mainmenu2.php';
}else{
include 'mainmenu1.php';
}
?>

<div id="main_center_block">
<?php
afficherUnArticleParId($_REQUEST["id"]);
if(sessionIsStarted()){
if(admin()){
	echo '<form action="commentaire.php" method="POST" style="display:inline; border:radius:10px;">';
	echo '<input type="hidden" value="'.$_REQUEST["id"].'" name="_id">';
	echo '<textarea name="comment" cols="50" rows="5" placeholder="Ajouter votre commentaire"></textarea></br>';
	echo '<input type="submit" value="Commenter">';
	echo '</form>';
	if(!publie($_REQUEST["id"])){
		echo '<form action="publication.php" method="POST" style="display:inline">';
		echo '<input type="hidden" value="'.$_REQUEST["id"].'" name="_id">';
		echo '<input type="submit" value="Publier">';
		echo '</form>';
	}else{
		echo '<form action="unpublication.php" method="POST" style="display:inline">';
		echo '<input type="hidden" value="'.$_REQUEST["id"].'" name="_id">';
		echo '<input type="submit" value="Bloquer">';
		echo '</form>';
	}
	echo '<form action="suppressionArticleAdmin.php" method="POST" style="display:inline">';
	echo '<input type="hidden" value="'.$_REQUEST["id"].'" name="_id">';
	echo '<input type="submit" value="Supprimer">';
	echo '</form>';
}else{


echo '<form action="commentaire.php" method="POST" style:"border-radius:10px">';
echo '<input type="hidden" value="'.$_REQUEST["id"].'" name="_id">';
echo '<textarea name="comment" cols="50" rows="5" placeholder="Ajouter votre commentaire"></textarea></br>';
echo '<input type="submit" value="Commenter">';
echo '</form>';
}
}
?>
</div>
</body>
</html>
