<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->users;
include'fonctions.php';

if(!userExist($_POST["login"],$_POST["mdp"])){
	include'FormulaireConnexion.php';
	echo '<script>alert("Login or password is incorrect")</script>';
}else{
	startingSession($_POST["login"],$_POST["mdp"]);
	header('location:index.php');
	}

?>
