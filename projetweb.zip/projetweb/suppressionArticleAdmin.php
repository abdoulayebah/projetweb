<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->articles;
include 'fonctions.php';
if(!sessionIsStarted()){
		header ('location:index.php');
		}
supprimerArticle($_REQUEST["_id"]);
header('location:administration.php');
?>
