<?php
session_start();
include '../TP8/connectBase.php';
		$db=$m->abdbah39;
		$collection=$db->articles;
	
	
	
	$cursor=$collection->find(array("_id"=>new MongoId($_REQUEST["_id"])));
	foreach($cursor as $c=>$v){
		foreach($v as $clef=>$val){
		if($clef=="comments") {
		$val[]=array("auteur"=>$_SESSION["prenom"],"text"=>$_REQUEST["comment"]);
		$newdata=array('$set'=>array("comments"=>$val));
		$collection->update(array("_id"=>new MongoId($_REQUEST["_id"])),$newdata);
		}
	}
	}
	header('location:afficherUnArticle.php?id='.$_REQUEST["_id"]);


?>
