<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Affichage</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
<?php
session_start();
include '../TP8/connectBase.php';
$db=$m->abdbah39;
$collection=$db->articles;
include'fonctions.php';
if(!sessionIsStarted()){
		header ('location:index.php');
		exit;
		}
		include 'mainmenu2.php';
		
		$query=array("_id"=>new MongoId($_REQUEST["_id"]));
		$cursor=$collection->find($query);
				echo '<div id="main_center_block">';
				echo '<div class="FormulaireDepotDArticle">';
				echo '<form action="do_modification.php" method="POST">';
				echo'<div class="contenuFormulaire">';
			foreach($cursor as $c=>$v){
								
				echo '<input type="text" name="titre" id="titreArticle" value="'.$v["titre"].'"><br />';
				echo '<input type="text" name="image" id="image" value="'.$v["image"].'"><br />';
				echo '<textarea name="contenu" rows="15" cols="90" id="contenu">'.$v["contenu"].'</textarea></br>';
				echo '<input type="hidden" name="id" value="'.$_REQUEST["_id"].'">';
				echo '<div class="motClef">';
				echo '<input type="text" name="cle1" id="mot1" value="'.$v["cle1"].'">';
				echo '<input type="text" name="cle2" id="mot2" value="'.$v["cle2"].'">';
				echo '<input type="text" name="cle3" id="mot3" value="'.$v["cle3"].'">';
				echo '<input type="text" name="cle4" id="mot4" value="'.$v["cle4"].'">';
				echo '</div>';
				echo '<div class="Soumettre">';
				echo '<input type="submit" value="Modifier" id="boutonSoumettre">';
				echo '</div>';
			}
			echo '</div>';
			echo '</form>';
			echo '</div>';
		
		?>
			




</div>
</body>
</html>
